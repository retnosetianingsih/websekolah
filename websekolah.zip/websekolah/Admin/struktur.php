<section id="about-us">
        <div class="container">			
			<div class="skill-wrap clearfix">			
				<div class="center wow fadeInDown">
                    <h2>Struktur Organisasi</h2></div>
                    <center>
                        <img class="img img-responsive" src="images/struktur.jpg" width=80% height=80% alt="Struktur Organisasi">
					
			</div><!--section-->
		</div><!--/.container-->
    </section><!--/about-us-->