<section id="about-us">
        <div class="container">			
			<div class="skill-wrap clearfix">			
				<div class="center wow fadeInDown">
					<h2>Data Siswa</h2>
                </div>	
                
                <table class="table table-responsive table-hover">
                    <thead>
                        <tr>
                            <th>NIS</th>
                            <th>Nama Siswa</th>
                            <th>L/P</th>
                            <th>Tempat, Tanggal Lahir</th>
                            <th>Alamat</th>
                            <th>Tahun Masuk</th>
                        </tr>
                    </thead>

                    <tbody>
                        <tr>
                            <td>161530009</td>
                            <td>Erik Wibowo</td>
                            <td>L</td>
                            <td>Pekalongan, 30-Juni-1998</td>
                            <td>Dukuh Bubak 01/07 Desa Kebonagung Kecamatan Kajan Kabupaten Pekalongan</td>
                            <td>2017</td>
                        </tr>
                    </tbody>
                </table>

			</div><!--section-->
		</div><!--/.container-->
    </section><!--/about-us-->